Ce projet repond au cahier des charges d'un client

Chaque fonction a été réaliser individuellement

#Repartition des tâches

Anis
-Ajout des clients
-Verifier si l'annuaire est valide
-Charger annuaire
-La modification autre que mel client
-La recherche du mail client
-La suppression d'un client

Cyprien
-Filtrer les donnes manquantes
-Affichage trie par nom
- Filtrer combiner deux champs

Aragorn
-Filtrer un champ
-Modifier mail client

#Compilation
Pour pouvoir lancer notre programme, il faudra tout d'abord cloner le projet sur git pour pouvoir l'ouvrir sur Code Blocks. Assurez notamment que vous respecter bien la norme C99. Ensuite vous pouvez compiler puis run.

#Test
Vous pouvez tester notre programme en entrant un fichier au debut du lancement du programme. Le programme marche pour la plupart des fonctions mais quelque imperfections sont tout de même present.

#Environnement
L'execution du code est fait avec la norme C99 pour une meilleur gestion des erreurs